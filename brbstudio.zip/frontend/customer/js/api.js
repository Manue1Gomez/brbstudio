export async function postJson(url, payload) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  const data = await response.json().catch(() => ({}));

  return { ok: response.ok, status: response.status, data };
}

export async function getJson(url) {
  const response = await fetch(url);
  const data = await response.json().catch(() => ({}));

  return { ok: response.ok, status: response.status, data };
}
